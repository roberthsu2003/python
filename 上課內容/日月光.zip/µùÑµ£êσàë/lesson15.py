def abc():
    global a
    a = 10


a = 5
abc()
print(a)
