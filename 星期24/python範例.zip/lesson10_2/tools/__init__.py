from random import choice
from . import games

OK = True

def getWeek():
    return choice(["星期一","星期二","星期三","星期四","星期五","星期六","星期日"])

class Student():
    pass

def getStudent():
    return Student()
