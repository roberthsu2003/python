import tools

if __name__ == "__main__":
    print(tools.getWeek())
    tools.games.guessGame()